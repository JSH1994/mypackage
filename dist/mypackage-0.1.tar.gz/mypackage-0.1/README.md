#my_first_python_package
This is a tutorial for creating a python package for publishing

# How to install